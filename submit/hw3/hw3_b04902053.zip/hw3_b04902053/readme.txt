# 計算機結構 hw3

1. code 是怎麼實作

  - 從 hw2 修改
  - 遞迴的時候，會先把 $a0 和 $ra 都存到 stack ，之後再去 call 別的 function 。 call 完別的 function 之後，再把 $a0 和 $ra 還原回來。

2. 編寫的平台(Ex: Windows, Linux or Apple)

    Windows 10
